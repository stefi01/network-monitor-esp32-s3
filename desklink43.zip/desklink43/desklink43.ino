/*
  WiFi Monitor — Freenove FNK0115B, 4.3 inch, 480x272.
  Your own Wi-Fi signal, a ping to the house router, and a ping out
  to the internet. Best and worst ping reset at midnight.
  Prefs name link43. Does not list other devices.
  Arduino: ESP32S3 Dev Module, PSRAM OPI PSRAM, Flash 16MB,
  USB CDC On Boot Enabled.
  Screen clock 9000000, bounce 272 * 20.
*/

#include <Arduino_GFX_Library.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiUdp.h>
#include <Preferences.h>
#include <SPI.h>
#include "XPT2046_Touchscreen.h"
#include "ping/ping_sock.h"
#include "lwip/ip_addr.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#define SW 480
#define SH 272
#define PREF_NS "link43"
#define GFX_BL 2
#define PIN_DE 40
#define PIN_VSYNC 41
#define PIN_HSYNC 39
#define PIN_PCLK 42
#define TOUCH_SCK 12
#define TOUCH_MISO 13
#define TOUCH_MOSI 11
#define TOUCH_CS 38
#define TOUCH_IRQ 18

enum { PG_HOME = 0, PG_INFO, PG_GRAPH, PG_WIFI };

struct Key {
  int16_t x, y, w, h, code;
};

const uint16_t COL_BG = 0x0841;
const uint16_t COL_CARD = 0x2124;
const uint16_t COL_GOLD = 0xFE60;
const uint16_t COL_WHITE = 0xFFFF;
const uint16_t COL_DIM = 0xBDF7;
const uint16_t COL_GREEN = 0x07E0;
const uint16_t COL_RED = 0xF800;
const uint16_t COL_LINE = 0x4208;

Arduino_ESP32RGBPanel *rgbBus = nullptr;
Arduino_GFX *gfx = nullptr;
Preferences prefs;
XPT2046_Touchscreen ts(TOUCH_CS, TOUCH_IRQ);

char wifiSsid[33];
char wifiPass[65];
char zoneLabel[32];
char tzPosix[28];
bool zoneOk = false;
char ispName[48];
char publicIp[20];
char routerName[40];
int lanCount = -1;
uint32_t lastSweep = 0;
#define HIST 36
int rssiHist[HIST];
int pingHist[HIST];
int nHist = 0;
int page = PG_HOME;
bool wifiOk = false;
int houseMs = -1;
int netMs = -1;
int bestMs = -1;
int worstMs = -1;
int drops = 0;
int dropDay = 0;
bool wasNet = false;
char scanName[4][33];
int nScan = 0;
bool scanWait = false;
bool keysNum = false;
int wifiFocus = 0;
Key keys[48];
int nKeys = 0;
volatile int job = 0;
volatile bool busy = false;
volatile bool dirty = false;
uint32_t lastPing = 0;
uint32_t lastTap = 0;
int shownMin = -1;
volatile int pingResult = -2;
volatile bool pingFinished = false;

bool hit(int x, int y, int x0, int y0, int x1, int y1) {
  return x >= x0 && x < x1 && y >= y0 && y < y1;
}

int readFinger(int *x, int *y) {
  if (!ts.touched()) return 0;
  TS_Point a = ts.getPoint();
  delay(4);
  if (!ts.touched()) return 0;
  TS_Point b = ts.getPoint();
  if (abs(a.x - b.x) > 20 || abs(a.y - b.y) > 20) return 0;
  int px = map(((int)a.x + (int)b.x) / 2, 3800, 170, 0, SW - 1);
  int py = map(((int)a.y + (int)b.y) / 2, 250, 3800, 0, SH - 1);
  *x = constrain(SW - 1 - px, 0, SW - 1);
  *y = constrain(SH - 1 - py, 0, SH - 1);
  return 1;
}

void useZone() {
  if (!tzPosix[0]) return;
  setenv("TZ", tzPosix, 1);
  tzset();
}

void applyNetOffset(int apiOffset) {
  int west = -apiOffset;
  int mag = west < 0 ? -west : west;
  int hh = mag / 3600;
  int mm = (mag % 3600) / 60;
  if (west >= 0) {
    if (mm) snprintf(tzPosix, sizeof(tzPosix), "LCL%d:%02d", hh, mm);
    else snprintf(tzPosix, sizeof(tzPosix), "LCL%d", hh);
  } else if (mm) snprintf(tzPosix, sizeof(tzPosix), "LCL-%d:%02d", hh, mm);
  else snprintf(tzPosix, sizeof(tzPosix), "LCL-%d", hh);
  useZone();
}

void zoneFromPlace(const char *in) {
  const char *p = strrchr(in, '/');
  p = p ? p + 1 : in;
  int j = 0;
  while (*p && *p != '\r' && *p != '\n' && j < (int)sizeof(zoneLabel) - 1) {
    zoneLabel[j++] = (*p == '_') ? ' ' : *p;
    p++;
  }
  zoneLabel[j] = 0;
}

bool pullZone() {
  if (WiFi.status() != WL_CONNECTED) return false;
  WiFiClient client;
  HTTPClient http;
  http.setTimeout(4000);
  http.setConnectTimeout(3000);
  if (!http.begin(client, "http://ip-api.com/line/?fields=status,offset,timezone,isp,query")) return false;
  int code = http.GET();
  if (code != 200) {
    http.end();
    return false;
  }
  char body[240];
  int n = 0;
  WiFiClient *stream = http.getStreamPtr();
  uint32_t t0 = millis();
  while (n < (int)sizeof(body) - 1 && millis() - t0 < 3000) {
    int a = stream->available();
    if (a <= 0) {
      if (!http.connected()) break;
      delay(2);
      continue;
    }
    if (a > (int)sizeof(body) - 1 - n) a = (int)sizeof(body) - 1 - n;
    int r = stream->read((uint8_t *)body + n, a);
    if (r <= 0) break;
    n += r;
  }
  body[n] = 0;
  http.end();
  char *line2 = strchr(body, '\n');
  if (!line2 || strncmp(body, "success", 7) != 0) return false;
  *line2++ = 0;
  if (*line2 == '\r') line2++;
  char *line3 = strchr(line2, '\n');
  if (!line3) return false;
  *line3++ = 0;
  if (*line3 == '\r') line3++;
  char *line4 = strchr(line3, '\n');
  char *line5 = 0;
  if (line4) {
    *line4++ = 0;
    if (*line4 == '\r') line4++;
    line5 = strchr(line4, '\n');
    if (line5) {
      *line5++ = 0;
      if (*line5 == '\r') line5++;
    }
  }
  applyNetOffset(atoi(line2));
  zoneFromPlace(line3);
  zoneOk = zoneLabel[0] != 0;
  if (line4) copyField(line4, ispName, sizeof(ispName));
  if (line5) copyField(line5, publicIp, sizeof(publicIp));
  return zoneOk;
}

int ymdNow() {
  time_t now = time(nullptr);
  if (now < 100000) return 0;
  struct tm t;
  useZone();
  localtime_r(&now, &t);
  return (t.tm_year + 1900) * 10000 + (t.tm_mon + 1) * 100 + t.tm_mday;
}

void savePrefs() {
  prefs.begin(PREF_NS, false);
  prefs.putString("ssid", wifiSsid);
  prefs.putString("pass", wifiPass);
  prefs.putInt("drops", drops);
  prefs.putInt("day", dropDay);
  prefs.end();
}

void loadPrefs() {
  wifiSsid[0] = wifiPass[0] = 0;
  prefs.begin(PREF_NS, true);
  prefs.getString("ssid", wifiSsid, sizeof(wifiSsid));
  prefs.getString("pass", wifiPass, sizeof(wifiPass));
  drops = prefs.getInt("drops", 0);
  dropDay = prefs.getInt("day", 0);
  prefs.end();
}

void pingOk(esp_ping_handle_t hdl, void *) {
  uint32_t us = 0;
  esp_ping_get_profile(hdl, ESP_PING_PROF_TIMEGAP, &us, sizeof(us));
  if (us > 10000) us /= 1000;
  pingResult = (int)us;
}

void pingFail(esp_ping_handle_t, void *) { pingResult = -1; }
void pingEnd(esp_ping_handle_t, void *) { pingFinished = true; }

int pingOnce(IPAddress ip) {
  if ((uint32_t)ip == 0) return -1;
  pingResult = -2;
  pingFinished = false;
  esp_ping_config_t cfg = ESP_PING_DEFAULT_CONFIG();
  cfg.count = 1;
  cfg.timeout_ms = 800;
  cfg.interval_ms = 1000;
  cfg.target_addr = IPADDR4_INIT((uint32_t)ip);
  esp_ping_callbacks_t cbs;
  memset(&cbs, 0, sizeof(cbs));
  cbs.on_ping_success = pingOk;
  cbs.on_ping_timeout = pingFail;
  cbs.on_ping_end = pingEnd;
  esp_ping_handle_t hdl = nullptr;
  if (esp_ping_new_session(&cfg, &cbs, &hdl) != ESP_OK) return -1;
  esp_ping_start(hdl);
  uint32_t t0 = millis();
  while (!pingFinished && millis() - t0 < 1400) delay(20);
  esp_ping_stop(hdl);
  esp_ping_delete_session(hdl);
  return pingResult < 0 ? -1 : pingResult;
}

int pingFast(IPAddress ip) {
  if ((uint32_t)ip == 0) return -1;
  pingResult = -2;
  pingFinished = false;
  esp_ping_config_t cfg = ESP_PING_DEFAULT_CONFIG();
  cfg.count = 1;
  cfg.timeout_ms = 40;
  cfg.interval_ms = 50;
  cfg.target_addr = IPADDR4_INIT((uint32_t)ip);
  esp_ping_callbacks_t cbs;
  memset(&cbs, 0, sizeof(cbs));
  cbs.on_ping_success = pingOk;
  cbs.on_ping_timeout = pingFail;
  cbs.on_ping_end = pingEnd;
  esp_ping_handle_t hdl = nullptr;
  if (esp_ping_new_session(&cfg, &cbs, &hdl) != ESP_OK) return -1;
  esp_ping_start(hdl);
  uint32_t t0 = millis();
  while (!pingFinished && millis() - t0 < 70) delay(5);
  esp_ping_stop(hdl);
  esp_ping_delete_session(hdl);
  return pingResult < 0 ? -1 : pingResult;
}

void countLan() {
  IPAddress me = WiFi.localIP();
  if ((uint32_t)me == 0) return;
  int hits = 0;
  for (int host = 1; host <= 254; host++) {
    if (host == me[3]) continue;
    if (pingFast(IPAddress(me[0], me[1], me[2], host)) >= 0) hits++;
  }
  lanCount = hits;
}

void notePing(int ms) {
  int day = ymdNow();
  if (day && day != dropDay) {
    dropDay = day;
    drops = 0;
    bestMs = -1;
    worstMs = -1;
    savePrefs();
  }
  if (ms < 0) {
    if (wasNet) {
      drops++;
      savePrefs();
    }
    wasNet = false;
    return;
  }
  wasNet = true;
  if (bestMs < 0 || ms < bestMs) bestMs = ms;
  if (worstMs < 0 || ms > worstMs) worstMs = ms;
}

void pullLink() {
  if (!zoneOk || !ispName[0]) pullZone();
  if (!routerName[0]) pullRouter();
  houseMs = pingOnce(WiFi.gatewayIP());
  netMs = pingOnce(IPAddress(1, 1, 1, 1));
  notePing(netMs);
  if (lastSweep == 0 || millis() - lastSweep > 180000UL) {
    countLan();
    lastSweep = millis();
  }
  pushAll();
}


void netTask(void *) {
  for (;;) {
    if (job == 1) {
      pullLink();
      lastPing = millis();
      job = 0;
      busy = false;
      dirty = true;
    }
    vTaskDelay(pdMS_TO_TICKS(40));
  }
}

void clockText(char *out, int cap) {
  time_t now = time(nullptr);
  if (!zoneOk || now < 100000) {
    strlcpy(out, "--:--", cap);
    return;
  }
  struct tm t;
  useZone();
  localtime_r(&now, &t);
  int h = t.tm_hour % 12;
  if (h == 0) h = 12;
  snprintf(out, cap, "%d:%02d %s", h, t.tm_min, t.tm_hour < 12 ? "AM" : "PM");
}

void dateText(char *out, int cap) {
  time_t now = time(nullptr);
  if (!zoneOk || now < 100000) {
    out[0] = 0;
    return;
  }
  struct tm t;
  useZone();
  localtime_r(&now, &t);
  static const char *MON[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
                              "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
  static const char *WDAY[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
  snprintf(out, cap, "%s %s %d", WDAY[t.tm_wday], MON[t.tm_mon], t.tm_mday);
}

void copyField(const char *in, char *out, int cap) {
  if (!in) {
    out[0] = 0;
    return;
  }
  int j = 0;
  while (*in && *in != '\r' && *in != '\n' && j < cap - 1) out[j++] = *in++;
  out[j] = 0;
}

void pushAll() {
  int rssi = wifiOk ? WiFi.RSSI() : -100;
  int ping = netMs < 0 ? 0 : netMs;
  if (nHist < HIST) {
    rssiHist[nHist] = rssi;
    pingHist[nHist] = ping;
    nHist++;
    return;
  }
  memmove(rssiHist, rssiHist + 1, (HIST - 1) * sizeof(int));
  memmove(pingHist, pingHist + 1, (HIST - 1) * sizeof(int));
  rssiHist[HIST - 1] = rssi;
  pingHist[HIST - 1] = ping;
}

void pullRouter() {
  if (WiFi.status() != WL_CONNECTED || routerName[0]) return;
  WiFiUDP udp;
  if (!udp.begin(0)) return;
  const char *msg =
      "M-SEARCH * HTTP/1.1\r\n"
      "HOST: 239.255.255.250:1900\r\n"
      "MAN: \"ssdp:discover\"\r\n"
      "MX: 1\r\n"
      "ST: urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\n"
      "\r\n";
  IPAddress addr(239, 255, 255, 250);
  udp.beginPacket(addr, 1900);
  udp.write((const uint8_t *)msg, strlen(msg));
  udp.endPacket();
  char packet[640];
  char loc[160];
  loc[0] = 0;
  uint32_t t0 = millis();
  while (millis() - t0 < 1200) {
    int n = udp.parsePacket();
    if (n <= 0) {
      delay(15);
      continue;
    }
    int r = udp.read((uint8_t *)packet, sizeof(packet) - 1);
    if (r < 0) r = 0;
    packet[r] = 0;
    char *p = strstr(packet, "LOCATION:");
    if (!p) p = strstr(packet, "Location:");
    if (!p) continue;
    p += 9;
    while (*p == ' ') p++;
    copyField(p, loc, sizeof(loc));
    break;
  }
  udp.stop();
  if (!loc[0]) return;
  WiFiClient client;
  HTTPClient http;
  http.setTimeout(4000);
  http.setConnectTimeout(3000);
  if (!http.begin(client, loc)) return;
  int code = http.GET();
  if (code != 200) {
    http.end();
    return;
  }
  char buf[256];
  char name[40];
  int nn = 0;
  int ti = 0;
  bool inTag = false;
  bool done = false;
  name[0] = 0;
  const char *tag = "<friendlyName>";
  WiFiClient *stream = http.getStreamPtr();
  uint32_t u0 = millis();
  while ((http.connected() || stream->available()) && millis() - u0 < 4000 && !done) {
    int n = stream->read((uint8_t *)buf, sizeof(buf));
    if (n <= 0) {
      delay(2);
      continue;
    }
    for (int i = 0; i < n && !done; i++) {
      unsigned char c = (unsigned char)buf[i];
      if (!inTag) {
        if (c == (unsigned char)tag[ti]) {
          ti++;
          if (!tag[ti]) inTag = true;
        } else ti = (c == '<') ? 1 : 0;
      } else if (c == '<') {
        done = true;
      } else if (nn == 0 && (c == ' ' || c == '\r' || c == '\n' || c == '\t')) {
      } else if (nn < (int)sizeof(name) - 1 && c >= 32 && c <= 126) {
        name[nn++] = (char)c;
      } else if (nn >= (int)sizeof(name) - 1) {
        done = true;
      }
    }
  }
  name[nn] = 0;
  http.end();
  if (name[0]) strlcpy(routerName, name, sizeof(routerName));
}

void seriesRange(const int *v, int n, int *lo, int *hi) {
  bool any = false;
  int a = 0;
  int b = 0;
  for (int i = 0; i < n; i++) {
    if (v[i] <= -10000) continue;
    if (!any) {
      a = b = v[i];
      any = true;
    } else {
      if (v[i] < a) a = v[i];
      if (v[i] > b) b = v[i];
    }
  }
  if (!any) {
    *lo = 0;
    *hi = 1;
    return;
  }
  int pad = (b - a) / 4;
  if (pad < 2) pad = 2;
  *lo = a - pad;
  *hi = b + pad;
  if (*hi <= *lo) *hi = *lo + 1;
}

void plotLine(int x, int y, int w, int h, const int *v, int n, int vmin, int vmax, uint16_t col) {
  gfx->drawRect(x, y, w, h, COL_LINE);
  if (n < 2 || vmax <= vmin) return;
  int span = vmax - vmin;
  for (int i = 1; i < n; i++) {
    int a = v[i - 1];
    int b = v[i];
    if (a <= -10000 || b <= -10000) continue;
    if (a < vmin) a = vmin;
    if (b < vmin) b = vmin;
    if (a > vmax) a = vmax;
    if (b > vmax) b = vmax;
    int x0 = x + 1 + (i - 1) * (w - 3) / (n - 1);
    int x1 = x + 1 + i * (w - 3) / (n - 1);
    int y0 = y + h - 2 - (a - vmin) * (h - 4) / span;
    int y1 = y + h - 2 - (b - vmin) * (h - 4) / span;
    gfx->drawLine(x0, y0, x1, y1, col);
  }
}

void paintChips() {
  const char *labs[] = {"HOME", "INFO", "GRAPH", "WIFI"};
  int ids[] = {PG_HOME, PG_INFO, PG_GRAPH, PG_WIFI};
  for (int i = 0; i < 4; i++) {
    int x = 6 + i * 118;
    bool on = page == ids[i];
    gfx->fillRoundRect(x, 248, 112, 20, 4, on ? COL_GOLD : COL_CARD);
    gfx->setTextSize(1);
    gfx->setTextColor(on ? COL_BG : COL_WHITE);
    int tw = (int)strlen(labs[i]) * 6;
    gfx->setCursor(x + (112 - tw) / 2, 254);
    gfx->print(labs[i]);
  }
}

void showPage() {
  if (page == PG_INFO) drawInfo();
  else if (page == PG_GRAPH) drawGraph();
  else if (page == PG_WIFI) drawWifi();
  else drawHome();
}

void drawHome() {
  gfx->fillScreen(COL_BG);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(8, 2);
  gfx->print("WIFI MONITOR");
  char clk[16];
  clockText(clk, sizeof(clk));
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(300, 2);
  gfx->print(clk);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_DIM);
  gfx->setCursor(8, 22);
  gfx->print(zoneOk ? zoneLabel : "setting clock");
  char day[20];
  dateText(day, sizeof(day));
  gfx->setCursor(220, 22);
  gfx->print(day);
  int rssi = wifiOk ? WiFi.RSSI() : -100;
  int nBar = 1;
  if (rssi > -55) nBar = 4;
  else if (rssi > -67) nBar = 3;
  else if (rssi > -75) nBar = 2;
  for (int i = 0; i < 4; i++) {
    int bh = 8 + i * 6;
    uint16_t c = (i < nBar && wifiOk) ? COL_GREEN : COL_CARD;
    gfx->fillRoundRect(8 + i * 14, 62 - bh, 10, bh, 2, c);
  }
  gfx->setCursor(70, 40);
  gfx->print(wifiOk ? wifiSsid : "no link");
  if (wifiOk) {
    gfx->setCursor(70, 52);
    gfx->printf("%d dBm  ch %d", rssi, WiFi.channel());
  }
  gfx->setTextSize(1);
  gfx->setTextColor(COL_DIM);
  gfx->setCursor(8, 70);
  if (houseMs < 0) gfx->print("house --");
  else gfx->printf("house %d ms", houseMs);
  gfx->setCursor(150, 70);
  if (netMs < 0) gfx->print("internet --");
  else gfx->printf("internet %d ms", netMs);
  gfx->setCursor(300, 70);
  if (lanCount < 0) gfx->print("connections --");
  else gfx->printf("connections %d", lanCount);
  gfx->setCursor(8, 88);
  gfx->print("company ");
  gfx->print(ispName[0] ? ispName : "--");
  gfx->setCursor(8, 104);
  gfx->print("router ");
  gfx->print(routerName[0] ? routerName : "--");
  gfx->setCursor(8, 120);
  gfx->print("this ");
  if (wifiOk) gfx->print(WiFi.localIP());
  else gfx->print("--");
  gfx->setCursor(200, 120);
  gfx->print("public ");
  gfx->print(publicIp[0] ? publicIp : "--");
  gfx->setCursor(8, 136);
  gfx->print("gateway ");
  if (wifiOk) gfx->print(WiFi.gatewayIP());
  else gfx->print("--");
  gfx->setCursor(8, 152);
  if (bestMs < 0) gfx->print("best --");
  else gfx->printf("best %d ms  worst %d ms  drops %d", bestMs, worstMs, drops);
  gfx->setCursor(8, 170);
  gfx->print("dns ");
  if (wifiOk) gfx->print(WiFi.dnsIP());
  else gfx->print("--");
  paintChips();
}

void drawInfo() {
  gfx->fillScreen(COL_BG);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(8, 4);
  gfx->print("LINK");
  gfx->setTextSize(1);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(8, 28);
  gfx->printf("ssid %s", wifiOk ? wifiSsid : "--");
  gfx->setCursor(8, 46);
  if (wifiOk) gfx->printf("bssid %s", WiFi.BSSIDstr().c_str());
  else gfx->print("bssid --");
  gfx->setCursor(8, 64);
  gfx->printf("channel %d    %d dBm", wifiOk ? WiFi.channel() : 0, wifiOk ? WiFi.RSSI() : 0);
  gfx->setCursor(8, 82);
  gfx->print("mac ");
  gfx->print(WiFi.macAddress());
  gfx->setCursor(8, 100);
  gfx->print("dns ");
  if (wifiOk) gfx->print(WiFi.dnsIP());
  else gfx->print("--");
  gfx->setCursor(8, 118);
  gfx->print("company ");
  gfx->print(ispName[0] ? ispName : "--");
  gfx->setCursor(8, 136);
  gfx->print("router ");
  gfx->print(routerName[0] ? routerName : "--");
  gfx->setCursor(8, 154);
  gfx->print("gateway ");
  if (wifiOk) gfx->print(WiFi.gatewayIP());
  else gfx->print("--");
  gfx->setCursor(8, 172);
  gfx->print("public ");
  gfx->print(publicIp[0] ? publicIp : "--");
  gfx->setCursor(8, 190);
  gfx->print("this ");
  if (wifiOk) gfx->print(WiFi.localIP());
  else gfx->print("--");
  paintChips();
}

void drawGraph() {
  char sig[16], ms[16];
  int lo, hi;
  if (wifiOk) snprintf(sig, sizeof(sig), "%d dBm", WiFi.RSSI());
  else strlcpy(sig, "--", sizeof(sig));
  if (netMs < 0) strlcpy(ms, "--", sizeof(ms));
  else snprintf(ms, sizeof(ms), "%d ms", netMs);
  gfx->fillScreen(COL_BG);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_GREEN);
  gfx->setCursor(8, 2);
  gfx->printf("SIGNAL  %s", sig);
  if (nHist >= 2) {
    seriesRange(rssiHist, nHist, &lo, &hi);
    plotLine(8, 14, 464, 100, rssiHist, nHist, lo, hi, COL_GREEN);
  } else gfx->drawRect(8, 14, 464, 100, COL_LINE);
  gfx->setTextColor(COL_WHITE);
  gfx->setCursor(8, 122);
  gfx->printf("INTERNET  %s", ms);
  if (nHist >= 2) {
    seriesRange(pingHist, nHist, &lo, &hi);
    plotLine(8, 134, 464, 100, pingHist, nHist, lo, hi, COL_WHITE);
  } else gfx->drawRect(8, 134, 464, 100, COL_LINE);
  paintChips();
}

void addKey(int x, int y, int w, int h, int code, const char *s) {
  gfx->fillRoundRect(x, y, w, h, 4, COL_CARD);
  gfx->setTextSize(1);
  gfx->setTextColor(COL_WHITE);
  int tw = (int)strlen(s) * 6;
  gfx->setCursor(x + (w - tw) / 2, y + (h - 8) / 2);
  gfx->print(s);
  if (nKeys < 48) {
    keys[nKeys].x = (int16_t)x;
    keys[nKeys].y = (int16_t)y;
    keys[nKeys].w = (int16_t)w;
    keys[nKeys].h = (int16_t)h;
    keys[nKeys].code = (int16_t)code;
    nKeys++;
  }
}

void drawWifi() {
  nKeys = 0;
  gfx->fillScreen(COL_BG);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_GOLD);
  gfx->setCursor(8, 4);
  gfx->print("WIFI");
  int nShow = 2;
  int sw = (SW - 16) / nShow;
  for (int i = 0; i < nScan && i < nShow; i++) {
    gfx->fillRoundRect(8 + i * sw, 26, sw - 4, 18, 4, COL_CARD);
    gfx->setTextSize(1);
    gfx->setTextColor(COL_WHITE);
    gfx->setCursor(12 + i * sw, 30);
    gfx->print(scanName[i]);
  }
  gfx->fillRoundRect(8, 48, SW - 16, 20, 4, COL_CARD);
  gfx->drawRoundRect(8, 48, SW - 16, 20, 4, wifiFocus == 0 ? COL_GOLD : COL_LINE);
  gfx->setCursor(12, 54);
  gfx->setTextColor(COL_DIM);
  gfx->print("name ");
  gfx->setTextColor(COL_WHITE);
  gfx->print(wifiSsid);
  gfx->fillRoundRect(8, 72, SW - 16, 20, 4, COL_CARD);
  gfx->drawRoundRect(8, 72, SW - 16, 20, 4, wifiFocus == 1 ? COL_GOLD : COL_LINE);
  gfx->setCursor(12, 78);
  gfx->setTextColor(COL_DIM);
  gfx->print("pw ");
  gfx->setTextColor(COL_WHITE);
  gfx->print(wifiPass);
  const char *r1 = keysNum ? "1234567890" : "qwertyuiop";
  const char *r2 = keysNum ? "-_.:@#+=/" : "asdfghjkl";
  const char *r3 = keysNum ? "()!?'" : "zxcvbnm";
  int gap = 3;
  int w1 = (SW - 8 - 9 * gap) / 10;
  int y0 = 98;
  int kh = 22;
  for (int i = 0; r1[i]; i++) {
    char lab[2] = {r1[i], 0};
    addKey(4 + i * (w1 + gap), y0, w1, kh - 2, r1[i], lab);
  }
  int n2 = (int)strlen(r2);
  int x2 = (SW - (n2 * w1 + (n2 - 1) * gap)) / 2;
  for (int i = 0; i < n2; i++) {
    char lab[2] = {r2[i], 0};
    addKey(x2 + i * (w1 + gap), y0 + kh, w1, kh - 2, r2[i], lab);
  }
  int n3 = (int)strlen(r3);
  for (int i = 0; i < n3; i++) {
    char lab[2] = {r3[i], 0};
    addKey(4 + i * (w1 + gap), y0 + kh * 2, w1, kh - 2, r3[i], lab);
  }
  addKey(4 + n3 * (w1 + gap), y0 + kh * 2, w1 * 2, kh - 2, 8, "DEL");
  addKey(4, y0 + kh * 3, 70, kh - 2, 1, "123");
  addKey(80, y0 + kh * 3, 220, kh - 2, ' ', "SPACE");
  int bw = (SW - 20) / 4;
  int actY = 196;
  const char *acts[] = {"JOIN", "FORGET", "BACK", "RESET"};
  for (int i = 0; i < 4; i++) {
    int x = 4 + i * (bw + 4);
    gfx->fillRoundRect(x, actY, bw, 28, 6, i == 0 ? COL_GOLD : COL_CARD);
    gfx->setTextColor(i == 0 ? COL_BG : COL_WHITE);
    int tw = (int)strlen(acts[i]) * 6;
    gfx->setCursor(x + (bw - tw) / 2, actY + 10);
    gfx->print(acts[i]);
  }
}

void typeKey(int code) {
  char *buf = wifiFocus == 0 ? wifiSsid : wifiPass;
  int cap = wifiFocus == 0 ? (int)sizeof(wifiSsid) : (int)sizeof(wifiPass);
  int n = (int)strlen(buf);
  if (code == 8) {
    if (n > 0) buf[n - 1] = 0;
  } else if (code == 1) keysNum = !keysNum;
  else if (code >= 32 && code < 127 && n < cap - 1) {
    buf[n] = (char)code;
    buf[n + 1] = 0;
  }
  drawWifi();
}

void startScan() {
  scanWait = true;
  nScan = 0;
  WiFi.mode(WIFI_STA);
  WiFi.scanNetworks(true);
}

void joinWifi() {
  savePrefs();
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.disconnect();
  delay(100);
  WiFi.begin(wifiSsid, wifiPass);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 12000) delay(50);
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (wifiOk) {
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    zoneOk = false;
    ispName[0] = 0;
    publicIp[0] = 0;
    routerName[0] = 0;
    pullZone();
    page = PG_HOME;
    lastPing = 0;
    drawHome();
  } else drawWifi();
}

void tapWifi(int x, int y) {
  int nShow = 2;
  int sw = (SW - 16) / nShow;
  for (int i = 0; i < nScan && i < nShow; i++) {
    if (hit(x, y, 8 + i * sw, 26, 8 + i * sw + sw - 4, 44)) {
      strlcpy(wifiSsid, scanName[i], sizeof(wifiSsid));
      wifiFocus = 1;
      drawWifi();
      return;
    }
  }
  if (hit(x, y, 8, 48, SW - 8, 68)) {
    wifiFocus = 0;
    drawWifi();
    return;
  }
  if (hit(x, y, 8, 72, SW - 8, 92)) {
    wifiFocus = 1;
    drawWifi();
    return;
  }
  for (int i = 0; i < nKeys; i++) {
    if (hit(x, y, keys[i].x, keys[i].y, keys[i].x + keys[i].w, keys[i].y + keys[i].h)) {
      typeKey(keys[i].code);
      return;
    }
  }
  int bw = (SW - 20) / 4;
  int actY = 196;
  if (hit(x, y, 4, actY, 4 + bw, actY + 28)) {
    joinWifi();
    return;
  }
  if (hit(x, y, 4 + (bw + 4), actY, 4 + (bw + 4) + bw, actY + 28)) {
    wifiSsid[0] = wifiPass[0] = 0;
    savePrefs();
    WiFi.disconnect(true, true);
    drawWifi();
    return;
  }
  if (hit(x, y, 4 + 2 * (bw + 4), actY, 4 + 2 * (bw + 4) + bw, actY + 28)) {
    page = PG_HOME;
    drawHome();
    return;
  }
  if (hit(x, y, 4 + 3 * (bw + 4), actY, 4 + 3 * (bw + 4) + bw, actY + 28)) {
    prefs.begin(PREF_NS, false);
    prefs.clear();
    prefs.end();
    delay(100);
    ESP.restart();
  }
}

void onTap(int x, int y) {
  if (page != PG_WIFI) {
    if (y >= 248 && y < 268) {
      for (int i = 0; i < 4; i++) {
        int x0 = 6 + i * 118;
        if (x >= x0 && x < x0 + 112) {
          if (i == 3) {
            page = PG_WIFI;
            drawWifi();
            startScan();
          } else {
            page = i;
            showPage();
          }
          return;
        }
      }
    }
    return;
  }
  tapWifi(x, y);
}

void pollScan() {
  if (!scanWait || page != PG_WIFI) return;
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_RUNNING) return;
  scanWait = false;
  if (n < 0) return;
  nScan = n > 4 ? 4 : n;
  for (int i = 0; i < nScan; i++) strlcpy(scanName[i], WiFi.SSID(i).c_str(), sizeof(scanName[i]));
  WiFi.scanDelete();
  drawWifi();
}

void connectWifi() {
  loadPrefs();
  if (!wifiSsid[0]) {
    page = PG_WIFI;
    drawWifi();
    startScan();
    return;
  }
  gfx->fillScreen(COL_BG);
  gfx->setTextColor(COL_WHITE);
  gfx->setTextSize(2);
  gfx->setCursor(8, 80);
  gfx->print("linking");
  WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  WiFi.begin(wifiSsid, wifiPass);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(50);
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (wifiOk) {
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    zoneOk = false;
    ispName[0] = 0;
    publicIp[0] = 0;
    routerName[0] = 0;
    pullZone();
  }
  page = PG_HOME;
  drawHome();
}

void setup() {
  Serial.begin(115200);
  pinMode(GFX_BL, OUTPUT);
  digitalWrite(GFX_BL, HIGH);
  SPI.begin(TOUCH_SCK, TOUCH_MISO, TOUCH_MOSI, TOUCH_CS);
  ts.begin();
  ts.setRotation(0);
  rgbBus = new Arduino_ESP32RGBPanel(
      PIN_DE, PIN_VSYNC, PIN_HSYNC, PIN_PCLK,
      45, 48, 47, 21, 14,
      5, 6, 7, 15, 16, 4,
      8, 3, 46, 9, 1,
      0, 8, 4, 43,
      0, 8, 4, 12,
      1, 9000000, false, 0, 0, 272 * 20);
  gfx = new Arduino_RGB_Display(SW, SH, rgbBus, 2, true);
  if (!gfx->begin()) {
    Serial.println("gfx begin failed");
    return;
  }
  gfx->setTextWrap(false);
  digitalWrite(GFX_BL, HIGH);
  xTaskCreatePinnedToCore(netTask, "linknet", 20480, nullptr, 1, nullptr, 0);
  connectWifi();
  lastTap = millis();
}

void loop() {
  pollScan();
  int x, y;
  if (readFinger(&x, &y) == 1 && millis() - lastTap > 180) {
    lastTap = millis();
    onTap(x, y);
  }
  if (dirty && !busy && page != PG_WIFI) {
    dirty = false;
    showPage();
  }
  wifiOk = WiFi.status() == WL_CONNECTED;
  if (!busy && wifiOk && page != PG_WIFI && (lastPing == 0 || millis() - lastPing > 20000UL)) {
    busy = true;
    job = 1;
  }
  if (page != PG_WIFI) {
    time_t now = time(nullptr);
    if (now > 100000) {
      struct tm t;
      useZone();
      localtime_r(&now, &t);
      int minute = t.tm_hour * 60 + t.tm_min;
      if (minute != shownMin) {
        shownMin = minute;
        showPage();
      }
    }
  }
  delay(8);
}
